"""Very small TCP port scanner (educational)."""
