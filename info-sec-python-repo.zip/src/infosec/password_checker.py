"""Simple password strength checker."""
