"""Simple AES-GCM helpers."""
